const app = getApp()
const db = wx.cloud.database()
var util = require("../../../utils/util.js")
Page({
  
  data: {
    userInfo: {},
    openid: "",
    nowPoints: 0,
    address: {},

    pointsTrashBag:2,
    pointsTissue:3,
    pointsPlasticWrap:4,
    
  },

  onLoad: function() {

    this.setData({
      userInfo: app.globalData.userInfo,
      nowPoints: app.globalData.points,
      openid: app.globalData.openid
    })
  },

  onShow: function(){
      var self = this;
      wx.getStorage({
        key: 'address',
        success: function (res) {
          self.setData({
            address: res.data
          })
        }
      })
  },

  exchangeTrashBag: function(){

    var TIME = util.formatTime(new Date())
    if (this.data.address.name && this.data.address.phone && this.data.address.detail){
      if (this.data.nowPoints < this.data.pointsTrashBag){
        wx.showToast({
          title: '您的积分不足',
          icon: 'none',
          duration: 1000
        })
      }
      else{
        db.collection('orders').add({
          data: {
            commodityName: "垃圾袋",
            thumb:"/images/trashBag.jpg",
            needPoints: this.data.pointsTrashBag,
            state: "已提交",
            name: this.data.address.name,
            address: this.data.address.detail,
            phone: this.data.address.phone,
            time: TIME
            },
          success: res => { 
            db.collection('user')
              .where({
                _openid: app.globalData.openid
              })
              .update({
                data: {
                  points: this.data.nowPoints - this.data.pointsTrashBag
                },
                success: res => {
                  app.globalData.points = this.data.nowPoints - this.data.pointsTrashBag
                  this.setData({
                    nowPoints: app.globalData.points
                  })
                  console.log(this.data.nowPoints)
                }
              })
            wx.showToast({
              title: '兑换成功',
              icon: 'susscess',
              duration: 1000
            })
          }
        })
      }
    }
    else{
      wx.showToast({
        title: '请先填写收货地址',
        icon: 'none',
        duration: 1000
      })
    }
  },

  exchangeTissue: function () {

    var TIME = util.formatTime(new Date())
    if (this.data.address.name && this.data.address.phone && this.data.address.detail) {
      if (this.data.nowPoints < this.data.pointsTissue) {
        wx.showToast({
          title: '您的积分不足',
          icon: 'none',
          duration: 1000
        })
      }
      else {
        db.collection('orders').add({
          data: {
            commodityName: "卫生纸",
            thumb: "/images/tissue.jpg",
            needPoints: this.data.pointsTissue,
            state: "已提交",
            name: this.data.address.name,
            address: this.data.address.detail,
            phone: this.data.address.phone,
            time: TIME
          },
          success: res => {
            db.collection('user')
              .where({
                _openid: app.globalData.openid
              })
              .update({
                data: {
                  points: this.data.nowPoints - this.data.pointsTissue
                },
                success: res => {
                  app.globalData.points = this.data.nowPoints - this.data.pointsTissue
                  this.setData({
                    nowPoints: app.globalData.points
                  })
                  console.log(this.data.nowPoints)
                }
              })
            wx.showToast({
              title: '兑换成功',
              icon: 'susscess',
              duration: 1000
            })
          }
        })
      }
    }
    else {
      wx.showToast({
        title: '请先填写收货地址',
        icon: 'none',
        duration: 1000
      })
    }
  },

  exchangePlasticWrap: function () {

    var TIME = util.formatTime(new Date())
    if (this.data.address.name && this.data.address.phone && this.data.address.detail) {
      if (this.data.nowPoints < this.data.pointsPlasticWrap) {
        wx.showToast({
          title: '您的积分不足',
          icon: 'none',
          duration: 1000
        })
      }
      else {
        db.collection('orders').add({
          data: {
            commodityName: "保鲜膜",
            thumb: "/images/plasticWrap.jpg",
            needPoints: this.data.pointsPlasticWrap,
            state: "已提交",
            name: this.data.address.name,
            address: this.data.address.detail,
            phone: this.data.address.phone,
            time: TIME
          },
          success: res => {
            db.collection('user')
              .where({
                _openid: app.globalData.openid
              })
              .update({
                data: {
                  points: this.data.nowPoints - this.data.pointsPlasticWrap
                },
                success: res => {
                  app.globalData.points = this.data.nowPoints - this.data.pointsPlasticWrap
                  this.setData({
                    nowPoints: app.globalData.points
                  })
                  console.log(this.data.nowPoints)
                }
              })
            wx.showToast({
              title: '兑换成功',
              icon: 'susscess',
              duration: 1000
            })
          }
        })
      }
    }
    else {
      wx.showToast({
        title: '请先填写收货地址',
        icon: 'none',
        duration: 1000
      })
    }
  },


})
