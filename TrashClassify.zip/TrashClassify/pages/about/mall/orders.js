const app = getApp()
const db = wx.cloud.database()

Page({
  
  data:{
    openid:'',
  },

  onLoad: function(){
    
    db.collection('orders').where({
      _openid: app.globalData.openid
    }).get({
      success: res => {
        this.setData({
          nowOrders: res.data,
        })
        // console.log('[数据库] [查询记录] 成功1: ', res)
        // console.log('[数据库] [查询记录] 成功1: ', res.data)
      },
    })

  }, 

  onShow: function() {
    this.setData({
      openid:app.globalData.openid
    })
    this.getOrdersList()
  },

  getOrdersList: function (e) {
    db.collection('orders').where({
      _openid: this.data.openid
    }).get({
      success: res => {
        this.setData({
          nowOrders: res.data,
        })
        // console.log('[数据库] [查询记录] 成功: ', res)
      },
    })
  }, 

})