//参考 https://www.jianshu.com/p/18efe304ecdb

var app = getApp()
const db =  wx.cloud.database()

Page({
  data: {
    questionList:[],       //题目
    index: 0,              // 题目序列
    chooseValue: [],       // 每道题所选的答案
    chooseType: [],        // 每道题所选的答案
    totalScore: 10,        // 总分
    wrongList: [],         // 错误的题目集合
    questionListName:[],   //抽取的题目中垃圾名称
    questionListType: [],  //抽取的题目中垃圾类型

    "options": [
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false        // 默认没有选中
      },
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false       
      },
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false
      },
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false
      },
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false
      },
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false
      },
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false
      },
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false
      },
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false
      },
      {
        "option": {
          "1": "可回收物",
          "2": "有害垃圾",
          "3": "厨余垃圾",
          "4": "其他垃圾",
        },
        "scores": 1,
        "checked": false
      },
    ],
    option: ["可回收物", "有害垃圾", "厨余垃圾", "其他垃圾"]

  },

  onLoad: function (options) {

    this.setData({
      openid: app.globalData.openid
    })

   //从searhData中随机取出10个记录
    db.collection('searchData')
      .aggregate()
      .sample({
        size: 10
      })
      .end().then(res => { 
        this.setData({
          questionList: res.list,                    
        })
        for (var i = 0; i < this.data.questionList.length; i++) {
          this.data.questionListName.push(this.data.questionList[i].name)
          this.data.questionListType.push(this.data.questionList[i].type)
        }
      })
  },

  //单选事件
  radioChange: function (e) {
    console.log('checkbox发生change事件，携带value值为：', e.detail.value)
    this.data.options[this.data.index].checked = "true"
    this.data.chooseValue[this.data.index] = e.detail.value
    this.data.chooseType[this.data.index] = this.data.option[Number(e.detail.value)-1]
  },

  //下一题和提交按钮
  nextSubmit: function () {
    // 如果没有选择
    if(this.data.chooseValue[this.data.index] == undefined || this.data.chooseValue[this.data.index].length == 0){
      wx.showToast({
        title: '请选择至少一个答案!',
        icon: 'none',
        duration: 1000,
        success: function () {
          return
        }
      })
      return
    }

    // 判断答案是否正确
    this.chooseError()

    // 判断是不是最后一题
    if (this.data.index < this.data.questionList.length - 1) {
      // 渲染下一题
      this.setData({
        index: this.data.index + 1
      })
    } 
    else {
      // 跳转到结果页
      let wrongList = JSON.stringify(this.data.wrongList)
      let chooseValue = JSON.stringify(this.data.chooseValue)
      let questionListName = JSON.stringify(this.data.questionListName)
      let questionListType = JSON.stringify(this.data.questionListType)
      let chooseType = JSON.stringify(this.data.chooseType)

      db.collection('user')
        .where({
          _openid: app.globalData.openid
        })
        .update({
          data: {
            points: app.globalData.points + this.data.totalScore
          },
          success: res => {
            app.globalData.points = app.globalData.points + this.data.totalScore
          }
        })

      wx.navigateTo({
        url: '/pages/about/test/result?totalScore=' + this.data.totalScore + '&wrongList=' + wrongList + '&chooseValue=' + chooseValue + '&questionListName=' + questionListName + '&questionListType=' + questionListType + '&chooseType=' + chooseType
      })
    }
  },

  //错题处理
  chooseError: function () {
    var trueValue = this.data.questionList[this.data.index]['sortId']
    var chooseVal = this.data.chooseValue[this.data.index]
    console.log('选择了' + chooseVal + '答案是' + trueValue)
    if (chooseVal.toString() != trueValue.toString()) {
      this.data.wrongList.push(this.data.index)
      this.setData({
        totalScore: this.data.totalScore - 1                            // 扣分操作
      })
    }
  }

})

