
Page({

  data: {
    chooseType: [],          
    questionListName: [],
    questionListType: [],
  },


  onLoad: function (options) {
    let chooseType = JSON.parse(options.chooseType)
    let questionListName = JSON.parse(options.questionListName)
    let questionListType = JSON.parse(options.questionListType)
    
    this.setData({

      chooseType: chooseType,
      questionListName: questionListName,
      questionListType: questionListType

    })

  },
  toAgain: function(){
    wx.navigateTo({
      url: '/pages/about/test/test',
    })
  }

})