
var app = getApp()

Page({

  data: {
    totalScore: 0,            // 分数
    wrongList: [],            // 错误的题数
    chooseValue: [],          // 选择的答案
    remark: ["好极了！你很棒棒哦", "哎哟不错哦", "别灰心，继续努力哦！"],     // 评语

    questionListName: [],
    questionListType: [],
    chooseType: [],
  },

  onLoad: function (options) {

    // console.log(options)
    let wrongList = JSON.parse(options.wrongList)
    let chooseValue = JSON.parse(options.chooseValue)
    let questionListName = JSON.parse(options.questionListName)
    let questionListType = JSON.parse(options.questionListType)
    let chooseType = JSON.parse(options.chooseType)

    this.setData({
      totalScore: options.totalScore,
      wrongList: wrongList,
      chooseValue: chooseValue,
      chooseType: chooseType,
      questionListName: questionListName,
      questionListType: questionListType
    })

  },

  // 查看答题详情
  toView: function () {

    let chooseType = JSON.stringify(this.data.chooseType)
    let questionListName = JSON.stringify(this.data.questionListName)
    let questionListType = JSON.stringify(this.data.questionListType)

    wx.navigateTo({
      url: '/pages/about/test/details?questionListName=' + questionListName + '&questionListType=' + questionListType + '&chooseType=' + chooseType
    })
  },

  // 返回首页
  toIndex: function () {
    wx.switchTab({
      url: '/pages/about/home/home',
    })
  }
})

