
Page({

  data: {

  },

  onLoad: function (options) {
    
  },

  toStart: function(){
    wx.navigateTo({
      url: '/pages/about/test/test',
    })
  }

})