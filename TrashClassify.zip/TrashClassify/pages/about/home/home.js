const app = getApp()
const db = wx.cloud.database()
var util = require("../../../utils/util.js")

Page({
  
  
  lang:"zh_CN",
  data: {
    
    //获取用户信息
    hasUserInfo: false,
    userInfo: {},
    canIUse: wx.canIUse('button.open-type.getUserInfo'),

    newUser: true,
    beforeLogin:true,
    nowPoints:0,
    firstPoints:0,
    loadModal:false
  },
  
  onLoad: function (options) {
    
    this.initUserInfo()                                 //获取头像、昵称等信息
    app.globalData.userInfo = this.data.userInfo        //将头像等信息存入全局变量

    this.judgeUser()
  },

  onShow: function(){
    this.setData({
      nowPoints: app.globalData.points
    })
  },
  
  initUserInfo: function () {
    if (app.globalData.userInfo) {
      this.setData({
        userInfo: app.globalData.userInfo,
        hasUserInfo: true
      })
    }
    else if (this.data.canIUse) {
      // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
      // 所以此处加入 callback 以防止这种情况
      app.userInfoReadyCallback = res => {
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
      }
    }
    else {
      // 在没有 open-type=getUserInfo 版本的兼容处理
      wx.getUserInfo({
        success: res => {
          app.globalData.userInfo = res.userInfo
          this.setData({
            userInfo: res.userInfo,
            hasUserInfo: true
          })
        }
      })
    }
  },
  //用于button手动触发，获取用户信息
  getUserInfo: function (e) {
    console.log(e)
    app.globalData.userInfo = e.detail.userInfo
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },

  judgeUser: function (e) {
    var that = this
    db.collection('user').where({
      _openid: app.globalData.openid
    }).get({
      success: res => {
        if (res.data.length == 0) {
          console.log("新用户")
        }
        else {
          console.log("非新用户")
          that.setData({
            newUser: false,
          })
        }
        if (this.data.newUser) {       //如果是新用户则注册
          console.log("点击注册登录")
        }
        else {
          console.log("直接登录")
          this.clickLogin()           //如果不是新用户则登录
        }
      }
    })
  },

  ifLogin: function(){
    var that = this
    wx.showModal({
      title: '您还未登录',
      content: '登陆后答题获取积分兑换礼品',
      success(res) {
        if (res.confirm) {
          that.clickRegisterLogin()
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },

  clickRegisterLogin: function(){

    app.globalData.points = this.data.firstPoints
    // console.log('me', app.globalData.points)
    var TIME = util.formatTime(new Date())
    this.setData({
      loadModal: true
    })
    setTimeout(() => {
      this.setData({
        loadModal: false
      })
    }, 2000)

    db.collection('user').add({
      data: {
        points: 0,                    //手动添加_openid字段会导致插入数据失败,数据库会自动加入_openid。
        nickname: this.data.userInfo.nickName, 
        time: TIME
      },
    })
    this.setData({
      beforeLogin: false,
      loadModal: false
    })
  },

  clickLogin: function () {
    this.setData({
      loadModal: true
    })
    setTimeout(() => {
      this.setData({
        loadModal: false
      })
    }, 2000)

    db.collection('user').where({
      _openid: app.globalData.openid
    }).get({
      success: res => {
        this.setData({
          nowPoints: res.data[0].points,
        })
        app.globalData.points = res.data[0].points
        // console.log('[数据库] [查询记录] 成功: ', app.globalData.points)
      },
    })
    this.setData({
      beforeLogin: false,
      loadModal: false
    })
  },

  toMall: function(){
    wx.navigateTo({
      url: '/pages/about/mall/home',
    })
  },

  toTest: function(){
    wx.navigateTo({
      url: '/pages/about/test/home',
    })
  }

})