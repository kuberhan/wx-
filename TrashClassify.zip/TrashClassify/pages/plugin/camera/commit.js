const db = wx.cloud.database()

Page({

  data: {
    array: ['可回收物', '有害垃圾', '厨余垃圾', '其他垃圾'],
    objectArray: [
      {
        id: 0,
        name: '可回收物'
      },
      {
        id: 1,
        name: '有害垃圾'
      },
      {
        id: 2,
        name: '厨余垃圾'
      },
      {
        id: 3,
        name: '其他垃圾'
      }
    ],
    index:0,
  },
  bindPickerChange: function(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      index: e.detail.value
    })
  },

  onLoad: function (options) {
    var keyword = options.keyword
    this.setData({
      keyword: keyword
    })
  },

  formSubmit: function (e) {
    var keyword = e.detail.value.keyword
    let index = parseInt(this.data.index)
    let type = this.data.array[index]
    if (keyword == undefined || keyword == null || keyword == "") {
      wx.showToast({
        title: '请输入垃圾名称',
        icon: "none"
      })
      return
    }
    this.setData({
      isCommiting: true
    })
    db.collection('commit').add({
      data: {
        sortid:index+1,
        type:type,
        name:keyword
      },
      success: res => {
        console.log(res)
        this.setData({
          isCommiting: false
        })
        wx.showToast({
          title: '提交成功，请勿再次提交',
          icon: "none"
        })
      }, 
      fail: res => {
        this.setData({
          isCommiting: false
        })
        wx.showToast({
          title: '提交失败',
          icon: "none"
        })
      }
    })
  },
  
})