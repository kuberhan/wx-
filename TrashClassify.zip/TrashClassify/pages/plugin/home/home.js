const  plugin = requirePlugin("WechatSI")
const manager = plugin.getRecordRecognitionManager()

Page({
 
  data: {
    txt:["请长按下方麦克风图标开始说话","说话时请增大声音、放慢语速、吐字清晰","识别成功后在灰色框中显示识别结果","点击灰色框查看其所属垃圾种类","能识别英文，但暂不支持英文垃圾分类查询"],
    recordState: false,                 //是否录音
    content: ""                         //语音识别返回的内容       
  },

  onLoad: function (options) {
    this.initRecord()
  },

  initRecord: function () {
    var that = this
    manager.onStop = function (res) {
      if (res.result == '') {
        wx.showModal({
          title: '提示',
          content: '听不清楚，请重新说一遍！',
          showCancel: false,
        })
        return
      }
      var text = res.result
      text = text.replace("。", "")
      that.setData({
        content: text
      })
    }
  },

  //语音  --按住说话
  touchStart: function (e) {
    this.setData({
      recordState: true,       //录音状态
    })
    manager.start({
      lang: 'zh_CN',
    })
  },

  //语音  --松开结束
  touchEnd: function (e) {
    this.setData({
      recordState: false
    })
    manager.stop()
  },

  voiceChange: function (e) {
    var content = this.data.content
    content = content.replace("。","")
    this.setData({
      content: content
    })
    wx.navigateTo({
      url: '/pages/plugin/camera/result?keyword=' + this.data.content,
    })
  },

})
