const app = getApp()
const db = wx.cloud.database()

Page({

  data: {

    MAX_LIMIT: 20,    //每次取20个数据
    page: 0,          //依次切换数据库页数
    dataCount: 0,     //对应类型的垃圾个数
    datas: [],        //最终取到的垃圾信息
 
    CustomBar: app.globalData.CustomBar,     //最上方垃圾切换栏的位置
    TabCur: 0,                               //当前垃圾切换栏编号
    tabNav: ['可回收物', '有害垃圾', '厨余垃圾', '其他垃圾'],    //当前垃圾切换栏各页面名称

    imageurl: [
      "../../../images/RecycleableWaste.png",
      "../../../images/HazardouAwaste.png",
      "../../../images/HouseholdfoodWaste.png",
      "../../../images/ResidualWaste.png",
    ],

    keyword: "",
    sorts: [{
      color: "#014782",
      bgcolor: "#e9e8e6",
      logo: "/images/RecycleableWaste.png",
      name: "可回收物",
      content: "是指可以再生循环的垃圾。主要包括废纸、塑料、玻璃、金属和布料五大类。",
      action: ["轻投轻放", "清洁干燥，避免污染", "废纸尽量平整", "立体包装物请清空内容物，清洁后压扁投放", "有尖锐边角的，应包裹后投放"],
      voice: "可回收物就是可以再生循环的垃圾。主要包括废纸、塑料、玻璃、金属和布料五大类。请轻投轻放, 清洁干燥，避免污染, 废纸尽量平整, 立体包装物请清空内容物，清洁后压扁投放, 有尖锐边角的，应包裹后投放",
    },
      {
      color: "#e73322",
      bgcolor: "#c8e2f8",
      logo: "/images/HazardouAwaste.png",
      name: "有害垃圾",
      content: "是指对人体健康或者自然环境造成直接或潜在危害的废弃物。",
      action: ["投放时请注意轻放", "易破损的请连带包装或包裹后轻放", "如易挥发，请密封后投放"],
      voice: "有害垃圾是指对人体健康或者自然环境造成直接或潜在危害的废弃物。投放时请注意轻放，易破损的请连带包装或包裹后轻放，如易挥发，请密封后投放",
    },
      {
      color: "#664035",
      bgcolor: "#d6d5d4",
      logo: "/images/HouseholdfoodWaste.png",
      name: "厨余垃圾",
      content: "也叫湿垃圾，是指日常生活产生的容易腐烂的废弃物。",
      action: ["纯流质的食物垃圾应倒进下水口", "有包装物的垃圾应将包装物去除后分类投放","包装物请投放到可回收物或其他垃圾容器"],
      voice: "厨余垃圾是指日常生活产生的容易腐烂的废弃物。纯流质的食物垃圾投放时应倒进下水口，有包装物的湿垃圾应将包装物去除后分类投放，包装物请投放到可回收物或其他垃圾容器",
    },
      {
      color: "#2c2b27",
      bgcolor: "#e9e8e6",
      logo: "/images/ResidualWaste.png",
      name: "其他垃圾",
      content: "也叫干垃圾，是指除有害垃圾、厨余垃圾、可回收物以外的其他生活废弃物。",
      action: ["尽量沥干水分", "难以辨识类别的垃圾投入其他垃圾容器内"],
      voice: "其他垃圾是指除有害垃圾、厨余垃圾、可回收物以外的其他生活废弃物。投放时请尽量沥干水分，难以辨识类别的生活垃圾投入其他垃圾容器内",
    }]
  },
  
  // 切换到“课堂”时，加载当前垃圾类型页面的相关信息
  onLoad: function (options) {
    this.data.dataCount = db.collection('searchData').where({
      sortId: this.data.TabCur+1
    }).count()
    this.onGetData()
  },
  
  // 切换垃圾类型，显示不同信息
  tabSelect(e) {
    this.setData({
      TabCur: e.currentTarget.dataset.id,
      scrollLeft: (e.currentTarget.dataset.id - 1) * 60
    })
    this.data.page = 0  //不加这个的话，换垃圾种类按钮的时候，数据加载时会直接判定为无数据。
    this.onGetData()
  },
  
  // 从数据库调用对应内容的数据
  onGetData: function () {
    wx.showLoading({
      title: '正在加载数据中.....',
    })
    if (this.data.dataCount < this.data.page * this.data.MAX_LIMIT) {
      wx.showToast({
        title: '数据已经加载完',
        icon: "none"
      })
      wx.hideLoading()
      return
    }

    var that = this
    if (this.data.page == 0) {
      this.data.datas = []
    }
    var datas = db.collection('searchData').skip(this.data.page * this.data.MAX_LIMIT).limit(this.data.MAX_LIMIT).where({
      sortId: that.data.TabCur+1
    }).get({
      success: function (res) {
        wx.hideLoading()
        that.data.page = that.data.page + 1
        for (var i = 0; i < res.data.length; i++) {
          that.data.datas.push(res.data[i])
        }
        that.setData({
          datas: that.data.datas
        })
      },
      fail: res => {
        wx.hideLoading()
        wx.showToast({
          title: '数据加载失败',
          icon: "none"
        })
      }
    })
  },

  //到达底部
  onReachBottom: function () {
    this.onGetData()
  },

})