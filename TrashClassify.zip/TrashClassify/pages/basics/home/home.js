const db = wx.cloud.database()

Page({
  
  data:{
    city:"",        //获取城市信息
    reward: ["cloud://trashclassify-08dkc.7472-trashclassify-08dkc-1301942618/reward.png"],          //赞赏码
  },
  //页面初始加载
  onLoad: function (options) {
    this.geo()
  },
  //点击搜索框跳转到搜索页面
  search: function () {
    wx.navigateTo({
      url: '/pages/basics/garbageSearch/garbageSearch'
    })
  },
  // 获取定位城市
  geo: function () {
    var _this = this;
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        var latitude = res.latitude
        var longitude = res.longitude
        wx.request({
          url: 'https://apis.map.qq.com/ws/geocoder/v1/' + "?location=" + latitude + ',' + longitude + "&key=" + 'P4OBZ-JJSCW-RRQRI-OE4SD-74GB2-DXBJM' + "&get_poi=1",
          data: {},
          header: { 'Content-Type': 'application/json' },
          method: 'GET',
          success: function (ops) {
            var city = ops.data.result.address_component.city
            city = city.replace("市", "")
            _this.setData({
              city: city
            })
          },
        })
      }
    })
  },
  //显示赞赏码
  previewImage: function () {
    wx.previewImage({
      urls: this.data.reward 
    })
  },   
  //跳转到拍照页面
  onBindCamera: function () {
    wx.navigateTo({
      url: '/pages/plugin/camera/camera',
    })
  },
})
