const db = wx.cloud.database()
Page({

  data: {
    MAX_LIMIT: 20,
    page: 0,
    dataCount: 0,
    datas: [],
    keyword: "",
    logo: "",
    isSHow: false,
    isHasData: true,
  },

  onLoad: function (options) {
    this.data.dataCount = db.collection('searchData').count()
  },
  //确认搜索
  searchIcon: function (e) {               
    this.data.keyword = e.detail.value
    this.data.page = 0
    this.onGetData()
  },
  //用于显示输入的文字
  bindKeyInput: function (e) {
    this.setData({ keyword: e.detail.value })
  },
  //关键词匹配数据库获取相应数据
  onGetData: function () {
    wx.showLoading({
      title: '正在加载数据中.....',
    })
    if (this.data.dataCount < this.data.page * this.data.MAX_LIMIT) {
      wx.showToast({
        title: '数据已经加载完',
        icon: "none"
      })
      wx.hideLoading()
      return
    }
    var that = this
    if (this.data.page == 0) {
      this.data.datas = []
    }
    var datas = db.collection('searchData').skip(this.data.page * this.data.MAX_LIMIT).limit(this.data.MAX_LIMIT).where({
      name: db.RegExp({
        regexp: that.data.keyword,
      })
    }).get({
      success: function (res) {
        wx.hideLoading()
        if (res.data.length == 0 && that.data.page == 0) {
          that.setData({
            isHasData: false
          })
        } else {
          for (var i = 0; i < res.data.length; i++) {
            that.data.datas.push(res.data[i])
          }
          that.setData({
            datas: that.data.datas,
            isHasData: true
          })
          that.data.page = that.data.page + 1
        }
      }
    })
  },
  // 点击垃圾，显示对应垃圾类型的图标
  onItemClick: function (event) {             
    var index = event.currentTarget.dataset.index
    var logoImg = ""
    switch (parseInt(index)) {
      case 1:
        logoImg = "/images/RecycleableWaste.png"
        break;
      case 2:
        logoImg = "/images/HazardouAwaste.png"
        break;
      case 3:
        logoImg = "/images/HouseholdfoodWaste.png"
        break;
      case 4:
        logoImg = "/images/ResidualWaste.png"
        break;
    }
    this.setData({
      logo: logoImg,
      isShow: !this.data.isShow
    })
  },
  //隐藏图标
  hideModal: function () {         
    this.setData({
      isShow: !this.data.isShow
    })
  },
  //到达页面底部刷新
  onReachBottom: function () {      
    this.onGetData()
  },
  //返回主页
  onGoHome: function () {
    wx.switchTab({
      url: '/pages/basics/home/home',
    })
  },
  //提交没收录的垃圾
  commit: function () {
    wx.navigateTo({
      url: '/pages/plugin/camera/commit?keyword=' + this.data.keyword,
    })
  },
})